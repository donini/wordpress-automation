<?php
/**
 * The main template file
 *
 */
 
 get_header(); ?>

<pre>

If you are reading this message, are two possible things can be hapening:
	1- You have not selected your theme that you just created.
	2- You do not create a template for this page or you not overwrite the index.php of project theme.

Read project documentation.

<a href="https://github.com/donini/wordpress-automation/README.md">https://github.com/donini/wordpress-automation/README.md</a>

</pre>

 <?php
 get_footer();?>