<?php
/**
 * DON Framework utils functions
 *
 */

function vdp($variable) {
	echo '<pre>';
	var_dump($variable);
	echo '</pre>';
}