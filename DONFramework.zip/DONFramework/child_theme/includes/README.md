# Includes

All theme classes, objects, and libraries should be hidden away in this `/includes` directory.