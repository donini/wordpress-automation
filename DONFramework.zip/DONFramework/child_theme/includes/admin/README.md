## Admin

All classes, objects and functions related to the admin panel of wordpress