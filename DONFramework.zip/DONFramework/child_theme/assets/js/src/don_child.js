 ( function( window, undefined ) {
	'use strict';
	/*child hue*/
 } )( this );