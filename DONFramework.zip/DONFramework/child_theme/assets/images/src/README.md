# Project Images

Only source images (i.e. non-sprites, PSDs, raw photos) should be placed in this directory.  Source files are meant to serve as a backup for any images that can be edited by an end user.