<?php
/**
 * The 404 template file
 *
 */
 
 get_header(); ?>

Page not found.

 <?php
 get_footer();?>